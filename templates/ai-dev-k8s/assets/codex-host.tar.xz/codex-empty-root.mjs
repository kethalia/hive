var u=Object.defineProperty;var i=(t,o)=>u(t,"name",{value:o,configurable:true});import{execFileSync as c}from"node:child_process";import{createHash as y}from"node:crypto";import{existsSync as f}from"node:fs";import{dirname as d,join as p}from"node:path";import{fileURLToPath as _}from"node:url";const g=i(t=>y("sha256").update(t).digest("hex"),"sha");const h=i(t=>JSON.stringify(i((function o(e){return Array.isArray(e)?e.map(o):e&&typeof e==="object"?Object.fromEntries(Object.keys(e).sort().map(r=>[r,o(e[r])])):e}),"sort")(t)),"canonical");function n(t,o,e,r,s,a){const m=String.raw`import sys,json,importlib.util,pathlib,time
sys.dont_write_bytecode=True
p=json.load(sys.stdin);source=pathlib.Path(p['module']);spec=importlib.util.spec_from_file_location('empty_managed',source);m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m);manager=m.ManagedProjects.installed(p['home'])
if p['operation']=='initialize':
 if not (manager.state/'root.json').exists():
  with manager.lock():pass
 result=None
elif p['operation']=='inspect':result=manager._inspect_empty_root(manager._installed_observer,p["lifetimeId"])
else:
 class Authority:
  guardian=manager._installed_observer
  def verify(self,proposal):
   m.require(manager._empty_digest(proposal)==p['claims']['emptyRoot']['proposalDigest'] and p['claims']['exp']*1000>time.time()*1000,'empty_root_authority_expired')
   return {'expiresAt':p['claims']['exp']*1000,'enrollmentToken':p['grant'],'anchor':p['claims']['emptyRoot']}
 result=manager._revalidate_empty_root(p['proposal'],Authority())
print(json.dumps(result,separators=(',',':')))`;const l=c("/usr/bin/python3",["-I","-c",m],{input:JSON.stringify({home:t,operation:o,proposal:e,grant:r,claims:s,lifetimeId:a,module:p(d(_(import.meta.url)),"managed-projects.py")}),env:{PATH:"/usr/bin:/bin",LANG:"C.UTF-8"},stdio:["pipe","pipe","pipe"],timeout:1e4,maxBuffer:32768});return JSON.parse(l)}i(n,"run");function R(t){return n(t,"initialize")}i(R,"initializeEmptyRoot");function S(t,o){if(!f(p(t,".local/state/hive/managed-projects/root.json")))return null;const e=n(t,"inspect",null,null,null,o);if(e&&Buffer.byteLength(JSON.stringify(e))>16384)throw new Error("empty_root_inventory_bound");return e}i(S,"inspectEmptyRoot");function E(t,o,e,r){if(!o||r.emptyRoot?.proposalDigest!==g(h(o))||r.exp*1e3<=Date.now())throw new Error("empty_root_authority_rejected");return n(t,"apply",o,e,r)}i(E,"applyEmptyRoot");export{E as applyEmptyRoot,R as initializeEmptyRoot,S as inspectEmptyRoot};
